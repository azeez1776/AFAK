"use strict";
(() => {
var exports = {};
exports.id = 91;
exports.ids = [91];
exports.modules = {

/***/ 5142:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 8212:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
(__webpack_require__(5142).config)();

const contact = async (req, res) => {
  let nodemailer = __webpack_require__(5184); //Gmail service


  const transporter = nodemailer.createTransport({
    service: 'Gmail',
    //Email and password in the .env file
    auth: {
      user: process.env.email,
      pass: process.env.password
    }
  }); //the mail object

  const mailData = {
    from: req.body.email,
    to: process.env.email,
    subject: `Message From ${req.body.email}`,
    text: "Hello" + " | Sent from: " + req.body.email,
    html: `<div>Hello there</div><p>Sent from:
      ${req.body.email}</p>`
  }; //sending the mail

  transporter.sendMail(mailData, function (err, info) {
    if (err) console.log(err);else console.log(info);
  });
  res.status(200);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contact);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8212));
module.exports = __webpack_exports__;

})();