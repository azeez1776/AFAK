"use strict";
exports.id = 808;
exports.ids = [808];
exports.modules = {

/***/ 9249:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Footer)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/facebook.svg
/* harmony default export */ const facebook = ({"src":"/_next/static/media/facebook.44a87b26.svg","height":27,"width":27});
;// CONCATENATED MODULE: ./public/insta.svg
/* harmony default export */ const insta = ({"src":"/_next/static/media/insta.6c569db7.svg","height":27,"width":27});
;// CONCATENATED MODULE: ./public/twitter.svg
/* harmony default export */ const twitter = ({"src":"/_next/static/media/twitter.c75920b2.svg","height":27,"width":27});
;// CONCATENATED MODULE: ./public/pattern2.png
/* harmony default export */ const pattern2 = ({"src":"/_next/static/media/pattern2.d159f462.png","height":343,"width":191,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAYAAADeM14FAAAAVklEQVR42mNABqzlDxgZ0AGaiofScI7ccicp9sp7RgwqGxmYuKrv8Mot81Rkr7qjzaC4moGdp+66lOyScCWwAAgw5X9gkVtuC1KhDzdDYuYEFraKB0YASycWe8rZg8YAAAAASUVORK5CYII="});
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Footer/index.tsx









const Footer = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
    className: "flex justify-between items-end w-full absolute bottom-0 pb-2 h-20",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col space-y-8 pl-12 pb-4",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-evenly",
        children: [/*#__PURE__*/jsx_runtime_.jsx((image_default()), {
          className: "ml-4 cursor-pointer",
          onClick: () => window.location.href = "http://facebook.com/afaktz",
          src: facebook,
          alt: "facebook"
        }), /*#__PURE__*/jsx_runtime_.jsx((image_default()), {
          className: "ml-4 cursor-pointer",
          src: twitter,
          onClick: () => window.location.href = "http://twitter.com/afaktz",
          alt: "twitter"
        }), /*#__PURE__*/jsx_runtime_.jsx((image_default()), {
          className: "ml-4 cursor-pointer",
          src: insta,
          onClick: () => window.location.href = "https://www.instagram.com/afaktz/",
          alt: "instagram"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-black/50 text-xs",
        children: "\xA9 2022 AFAK TANZANIA COMPANY LTD"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx((image_default()), {
      src: pattern2,
      alt: "pattern",
      width: 150,
      height: 220
    })]
  });
};

/* harmony default export */ const components_Footer = (Footer);

/***/ }),

/***/ 5585:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Header)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/pattern.png
/* harmony default export */ const pattern = ({"src":"/_next/static/media/pattern.8b61d9bc.png","height":304,"width":263,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAAtElEQVR42mPgbjrvIL+ewYYh94OO7OI4TZWtDNwMMMDVeMlZYT2DGUPeO125ZW5K4lMXirMUvOaCSDZc9gFKGjPkfNCSX2GkJNK3XZ6v8by49mEGVgbO+qv+YMnc9/pyS/21pedXiDAw/GeC6QyQX89gzlz8wkxyVr+A638GRgYGBgaxScsYGbgbLwbIr2OwY8h7K87A8B8sIdyzE0wzsFff8VfZxSDIgA0wlz6VgRrPhC4HAF7BM44OtaUKAAAAAElFTkSuQmCC"});
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Header/index.tsx







const Header = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex justify-between items-start w-full",
    children: [/*#__PURE__*/jsx_runtime_.jsx((image_default()), {
      src: pattern,
      alt: "pattern",
      width: 180,
      height: 200
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex space-x-6 text-blue px-12 py-12 cursor-pointer",
      children: [/*#__PURE__*/jsx_runtime_.jsx((link_default()), {
        href: "/about",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: "About"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
        href: "/contact",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: "Contact Us"
        })
      })]
    })]
  });
};

/* harmony default export */ const components_Header = (Header);

/***/ }),

/***/ 9918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/brand.51647797.png","height":306,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAASElEQVR42mMgGhgsyOc2m7KIw6H4Jadd1V12uITidgZGEG06ZWEEUEGEddvxOKvOg/4YJpjMmM6tu9SPg/8IA7PSVgZmoq0GADO9El7QwTs7AAAAAElFTkSuQmCC"});

/***/ })

};
;